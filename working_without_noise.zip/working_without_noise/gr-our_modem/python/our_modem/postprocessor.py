#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2026 fucking-us.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


import numpy as np
from gnuradio import gr
from scipy.signal import find_peaks
from collections import deque

class postprocessor(gr.sync_block):
    """
    docstring for block postprocessor
    """

    def __init__(self, t,fs,sensitivity,timeout):
        self.t = t
        self.fs = fs
        self.sensitivity = sensitivity
        self.timeout = timeout
        self.bits = []
        self.queue = deque([])
        self.output_string=''
        self.did_removed_preamble = False
        gr.sync_block.__init__(self,
            name="postprocessor",
            in_sig=[np.float32, ],
            out_sig=None)


    


    
    
    def work(self, input_items, output_items):
        in0 = input_items[0]
        sps = int(self.t*self.fs)
        self.queue.extend(in0)
        if (self.did_removed_preamble == False):
          
            while(True):
                if(self.queue[0] <0):
                    self.queue.popleft()
                else:
                    break
            self.did_removed_preamble = True

        while(len(self.queue) > (3 * sps)):

            dequeued_items = np.array([self.queue.popleft() for _ in range(3 * sps)])
            bit = postprocessor.decide_bit(dequeued_items,sps)
  
            self.bits.append(bit)

            if (len(self.bits) == 8):
               
                if all(bit == 1 for bit in self.bits):
                    print(self.output_string)
                    break
                output_char = self.bits_to_string(self.bits)
                print(output_char)
                self.output_string += output_char
              
                self.bits = []
    

            
        return len(input_items[0])

    @staticmethod
    def bits_to_string(bits_array):
        output_str = ""
        bytes = [bits_array[i:i+8] for i in range(0,len(bits_array),8)] #break into bytes arrays
        
        for byte in bytes:
            if byte:
                byte_string = "".join(map(str,byte)) # turn array to string
                ch = int(byte_string,2)
                output_str += chr(ch)
        return output_str
       

    @staticmethod
    def decide_bit(samples_array,sps): 
        binary_arr = (samples_array>0).astype(int)
        # print(f"sum {sum(binary_arr)}")
        if(sum(binary_arr)>(1.5*sps)):
            return 1
        else:
            return 0       