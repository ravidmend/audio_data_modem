import numpy as np
import matplotlib.pyplot as plt

data = np.fromfile('../../output.bin', dtype=np.float32)

plt.figure()
plt.plot(data)
plt.show()